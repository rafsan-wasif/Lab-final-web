<?php
$Bishal=range(11,20);
shuffle($Bishal);
for ($x=0; $x< 10; $x++)
{
echo $Bishal[$x].' ';
}
echo "\n"
?>
